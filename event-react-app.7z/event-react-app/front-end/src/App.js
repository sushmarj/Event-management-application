import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Header from './components/layout/Header';
import Home from './components/pages/Home';
import ListofEvent from './components/Event/ListofEvent';
import AddEvent from './components/Event/AddEvent'
import Notification from './components/pages/Notification';

import Login from './components/pages/Login';
import Register from './components/pages/Register';
import NotFound from './components/pages/NotFound';



class App extends Component {
  render() {
    return (
     <Router>
       <div>
         <Header />
         <div className="container">
         <Switch>
           <Route exact path="/" component={Home} />
           <Route exact path="/addEvent" component={AddEvent} />
           <Route exact path="/listofevent" component={ListofEvent} />
           <Route exact path="/notification" component={Notification} />
         
   
           
           <Route exact path="/login" component={Login} />
           <Route exact path="/register" component={Register} />
           <Route component={NotFound} />
         </Switch>
         </div>
       </div>
     </Router>
    );
  }
}

export default App;
