import React, { Component } from 'react';
import  createHistory from 'history/createBrowserHistory';
import axios from 'axios';
const history= createHistory();


class AddEvent extends Component {

    constructor() {
        super();
        this.serviceUrl = "http://localhost:5000/api/event";
        this.state = {
            post:[{
          
            eventname: "",
            start: "",
            end:"",
            image:" ",
            location:"",
            adultprice:"",
            childprice:"",
            vegprice:"",
            nonvegprice:"",
            drinksprice:"", 
            startbook:"",
            endbook:"",
            description: ""
        }]
    }
}
    
    onChanged = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }
    onSubmit=(event)=>{
        event.preventDefault();
        console.log(this.state);
        alert("posted");
        this.props.history.push('/');
        window.location.reload(); 

        let newPost=[...this.state.post];
            let newpost={
                eventname:this.state.eventname,
                start:this.state.start,
                end:this.state.end, 
                image:this.state.image, 
                location:this.state.location, 
                adultprice:this.state.adultprice, 
                childprice:this.state.childprice, 
                vegprice:this.state.vegprice,
                nonvegprice:this.state.nonvegprice,
                drinksprice:this.state.drinksprice, 
                startbook:this.state.startbook,
                endbook:this.state.endbook,
                description:this.state.description
            }
            axios.post(this.serviceUrl,newpost).then((res)=>{
                newPost.push(newpost);
                this.setState({post:newPost});
            })
    }
       componentDidMount() {
          let _id = this.props.match.params._id;
          axios.get(this.serviceUrl + _id).then((res) => {
             this.setState({
                event: res.data
             })
          })
        }
        cancelClick=()=>{
            this.props.history.push('/');
        }
    
    render() {

        const {  eventname, start, end, image, location, adultprice, childprice, vegprice, nonvegprice, drinksprice, startbook, endbook, description} = this.state;

        return (
            
            <div className="row">
            <div className="col-sm-offset-2 col-sm-8">
            <div className="well">
                <h2>Create a Event</h2> <hr/>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label> Event Name :</label>
                        <input name="eventname" onChange={this.onChanged}
                            value={eventname} type="text" className="form-control"  placeholder="Enter the Event Name" required/>                   
                    </div>

                    <div className="form-group">
                        <label> start Date/Time :</label>
                        <input name="start" onChange={this.onChanged}
                            value={start} type="date" className="form-control"  placeholder="Enter Start date of Event" required/>
                    </div>

                    <div className="form-group">
                        <label> End Date/Time :</label>
                        <input name="end" onChange={this.onChanged}
                            value={end} type="date" className="form-control"  placeholder="Enter End date of Event" required/>
                    </div>
                    <div className="form-group">
                        <label> image:</label>
                        <input name="images" onChange={this.onChanged}
                            value={image} src="url" className="form-control" type="file" />
                    
                    </div>


                    <div className="form-group">
                        <label> Location :</label>
                        <input name="location" onChange={this.onChanged}
                            value={location} type="text" className="form-control"  placeholder="Enter location" required/>
                    </div>
                    
                    <div className="form-group">    
                        <label> Adult Price :</label>
                        <input name="adultprice" onChange={this.onChanged}
                            value={adultprice} type="number" className="form-control"  placeholder="Enter price for adult" required/>
                    </div>
                    <div className="form-group">
                        <label> Child Price :</label>
                        <input name="childprice" onChange={this.onChanged}
                            value={childprice} type="number" className="form-control" placeholder="Enter price for child" />
                    </div>
                    <div className="form-group">
                        <label> Veg Price :</label>
                        <input name="vegprice" onChange={this.onChanged}
                            value={vegprice} type="number" className="form-control" placeholder="Enter price for Veg food" />
                    </div>
                    <div className="form-group">
                        <label> Non-veg Price :</label>
                        <input name="nonvegprice" onChange={this.onChanged}
                            value={nonvegprice} type="number" className="form-control" placeholder="Enter price for Non-veg food" />
                    </div>
                    <div className="form-group">
                        <label> Drinks Price :</label>
                        <input name="drinksprice" onChange={this.onChanged}
                            value={drinksprice} type="" className="form-control" placeholder="Enter price for Drinks Price" />
                    </div>
                    <div className="form-group">
                        <label> Start Booking Time :</label>
                        <input name="startbook" onChange={this.onChanged}
                            value={startbook} type="text" className="form-control" placeholder="Enter the start booking Time " />
                    </div>
                    <div className="form-group">
                        <label> End Booking Time :</label>
                        <input name="endbook" onChange={this.onChanged}
                            value={endbook} type="text" className="form-control" placeholder="Enter the End booking Time " />
                    </div>
                    <div className="form-group">
                        <label> Description :</label>
                        <input name="description" onChange={this.onChanged}
                            value={description} type="text" className="form-control" placeholder="Enter Description about the Event" required/>
                    </div>


                    <button  className="btn btn-primary" type="submit">Submit</button> &nbsp;&nbsp;&nbsp;
                    <button onClick={this.cancelClick} className="btn btn-danger">Cancel</button>
                   
                </form>
            </div>
           
            </div></div>
            
        )
    }
}

export default AddEvent;


