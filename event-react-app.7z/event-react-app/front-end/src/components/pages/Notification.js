import React from 'react';

const Notification=()=> {
        return(
            <h2>Welcome To Notification Component</h2>
        )
}

export default Notification;