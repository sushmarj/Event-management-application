import React, { Component } from 'react';
import axios from 'axios';

class EventDetails extends Component {
   constructor() {
      super();
      this.serviceUrl = "http://localhost:5000/api/event/";
      this.state = {
         event: [],
         user:[]
      }
   }
  
   componentDidMount() {
      let _id = this.props.match.params._id;
      axios.get(this.serviceUrl + _id).then((res) => {
         this.setState({
            event: res.data
         })
      })
   }
   
   apply = () => {
      this.props.history.push('/eventregistration/');
  }
   render() {
      return (
         <div>
            <div className="well">
            <img src={this.state.event.image} alt="" width="100" height="100"/>
            <h3>{this.state.event.eventname}</h3>
            <h3>{this.state.event.start}</h3>
            <h3>{this.state.event.end}</h3>
            <button className="btn btn-success" onClick={(_id)=>this.apply()}>Register</button>
            </div>
            <div className="well">
            <h3>Event Description</h3>{this.state.event.description}
            <h3>{this.state.event.location}</h3>
            <h3>{this.state.event.adultprice}</h3>
            <h3>{this.state.event.childprice}</h3>
            <h3>{this.state.event.food}</h3>
            <h3>{this.state.event.drinks}</h3>
            </div>
            
         </div>
      );
   }
}
export default eventDetails