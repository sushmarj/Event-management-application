import React, { Component } from 'react';

import  createHistory from 'history/createBrowserHistory';
const history= createHistory();


class AddEvent extends Component {

    constructor() {
        super();
        this.state = {
            eventname: '',
            start: '',
            end:'',
            image:'',
            location:'',
            adultprice:'',
            childprice:'',
            food:'',
            drinks:'',
            description: '',
            
            
            eventnameError: '',
            startError: '',
            endError: '',
            locationError: '',
            adultpriceError:'',
            childpriceError: '',
            foodError:'',
            drinksError:'',
            descriptionError:''
        }
    }

    onChanged = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    validate = () => {
        let isError = false;
        const errors = {
            eventnameError: "",
            startError: '',
            endError: '',
            locationError: '',
            adultpriceError:'',
            childpriceError: '',
            foodError:'',
            drinksError:'',
            descriptionError:''
        };
        if (this.state.eventname.length < 5) {
            isError = true;
            errors.eventnameError = "Eventname needs to be atleast 5 characters long";
        }
        if (this.state.eventname === '') {
            isError = true;
            errors.eventnameError = "Event name Required ";
        }

        if (this.state.start === '') {
            isError = true;
            errors.startError = "Requires valid start date";
        }
        if (this.state.end === '') {
            isError = true;
            errors.endError = "Requires valid end date ";
        }
        if (this.state.location === '') {
            isError = true;
            errors.locationError = "location Required ";
        }
        if (this.state.adultprice === '') {
            isError = true;
            errors.adultpriceError ="Price for Adult Required ";
        }
        if (this.state.childprice === '') {
            isError = true;
            errors.childpriceError = "Price for child Required ";
        }
        if (this.state.food === '') {
            isError = true;
            errors.foodError = "Food Required ";
        }
        if (this.state.drinks === '') {
            isError = true;
            errors.drinksError = "Drinks Required ";
        }
        if (this.state.description === '') {
            isError = true;
            errors.descriptionError = "Description Required ";
        }
       
        this.setState({
            ...this.state,
           ...errors
        });

        return isError;
    };



    onSubmit = (event) => {
        event.preventDefault();
        console.log(this.state);
        const err = this.validate();
        if (!err) {
            // clear form
            this.setState({
                eventname: '',
                eventnameError: "",
                start: '',
                startError: '',
                end:'',
                endError: '',
                image:'',
                location:'',
                locationError: '',
                adultprice:'',
                adultpriceError:'',
                childprice:'',
                childpriceError: '',
                food:'',
                foodError:'',
                drinks:'',
                drinksError:'',
                description: '',
                descriptionError:''
            });
            alert("Add the Event successfully")

            this.props.history.push('/home');
        }


    }

    render() {

        const {  eventname, start, end, image, location, adultprice, childprice, food, drinks, description,} = this.state;

        return (

            <div className="well">
                <h2>Create a Event</h2>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label> Event Name :</label>
                        <input name="eventname" onChange={this.onChanged}
                            value={eventname} type="text" className="form-control" />
                   <span style={{color: "red"}}>{this.state.eventnameError}</span>
                    </div>

                    <div className="form-group">
                        <label> start Date/Time :</label>
                        <input name="start" onChange={this.onChanged}
                            value={start} type="date" className="form-control" />
                    <span style={{color: "red"}}>{this.state.startError}</span>
                    </div>

                    <div className="form-group">
                        <label> End Date/Time :</label>
                        <input name="end" onChange={this.onChanged}
                            value={end} type="date" className="form-control" />
                    <span style={{color: "red"}}>{this.state.endError}</span>
                    </div>
                    <div className="form-group">
                        <label> image:</label>
                        <input name="image" onChange={this.onChanged}
                            value={image} type="file" className="form-control" />
                    </div>


                    <div className="form-group">
                        <label> Location :</label>
                        <input name="location" onChange={this.onChanged}
                            value={location} type="text" className="form-control" />
                    <span style={{color: "red"}}>{this.state.locationError}</span>
                    </div>
                    <div className="form-group">
                                      
                        <label> Adult Price :</label>
                        <input name="adultprice" onChange={this.onChanged}
                            value={adultprice} type="number" className="form-control" />
                    <span style={{color: "red"}}>{this.state.adultpriceError}</span>
                    </div>
                    <div className="form-group">
                        <label> Child Price :</label>
                        <input name="childprice" onChange={this.onChanged}
                            value={childprice} type="number" className="form-control" />
                    <span style={{color: "red"}}>{this.state.childpriceError}</span>
                    </div>
    
                    <div className="form-group">
                        <label> Food options :</label>&nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="checkbox"  value="veg" /> Veg &nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="checkbox"  value="nonveg" /> Non-Veg &nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="checkbox"  value="notapplicable" /> NotApplicable &nbsp; &nbsp;
                            <span style={{color: "red"}}>{this.state.foodError}</span>
                    </div>
                    <div className="form-group">
                        <label> Drinks :</label>&nbsp; &nbsp;
                        <input name="drinks" onChange={this.onChanged}
                            value={drinks} type="radio"  value="Applicable" /> Applicable &nbsp; &nbsp;
                        <input name="drinks" onChange={this.onChanged}
                            value={drinks} type="radio"  value="Not Applicable" /> Not Applicable
                            <span style={{color: "red"}}>{this.state.drinksError}</span>
                    </div>

                    <div className="form-group">
                        <label> Description :</label>
                        <input name="description" onChange={this.onChanged}
                            value={description} type="text" className="form-control" />
                    <span style={{color: "red"}}>{this.state.descriptionError}</span>
                    </div>


                    <button className="btn btn-primary" type="submit">submit</button>

                   
                </form>
            </div>

        )
    }
}

export default AddEvent;


