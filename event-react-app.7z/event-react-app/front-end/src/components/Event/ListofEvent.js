import React from 'react';

const ListofEvent=()=> {
        return(
            <h2>List of Event Component</h2>
        )
}

export default ListofEvent;