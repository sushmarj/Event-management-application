import React, { Component } from 'react';
import axios from 'axios';

class Home extends Component {
    constructor() {
        super(); 
        this.serviceUrl = "http://localhost:5000/api/event";
        this.state = {
            event: [],activePage: 2

        }
        this.onChangePage = this.onChangePage.bind(this);
    }
 
    onChangePage(pageOfItems) {
        // update state with new page of items
        this.setState({ pageOfItems: pageOfItems });
    }
    
    componentDidMount() {
        axios.get(this.serviceUrl).then((res) => {
            this.setState({ event: res.data });
        })
    }

    showDetails = (id) => {
    
        this.props.history.push('/eventdetails/'+id);
    }    
    render(){
        return(
            <div>
            <div className="row" className="Pagination">
                {this.props.event.map((j, i) => <div className="col-md-4">
                    <div className="thumbnail" width="50" height="50">
                        <img src={j.image} alt="not found" width="150" height="100"/>
                        {j.eventname}<br />
                        {j.start}<br/> 
                        {j.end}<br />
                        {j.location}<br/><br/>
        <button onClick={() => this.showDetails(j._id)}>Show More Details</button></div></div>)}
        </div>
        </div>
        );
}
}
export default Home;