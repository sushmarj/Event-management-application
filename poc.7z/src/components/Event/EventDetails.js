import React, { Component } from 'react';
import Eventregistration from './Eventregistration';
import axios from 'axios';

class EventDetails extends Component {
   constructor() {
      super();
      this.serviceUrl = "http://localhost:5000/api/event/";
      this.state = {
        
         event: [ ],
         user:[]

      }
   }
  
   componentDidMount() {
      let _id = this.props.match.params._id;
      axios.get(this.serviceUrl + _id).then((res) => {
         this.setState({
            event: res.data
         })
      })
   }
   
   apply = (_id) => {
      alert(_id);
      this.props.history.push('/eventregistration/'+ _id);
  }
   render() {
  
      return (
         <div>
            <div className="well">
            <img className="img-fluid"  src={this.state.event.image} alt="not found" width="400" height="300"/>
            <h3>{this.state.event.eventname}</h3>
            <h4 className="text-left" > {this.state.event.start}&nbsp;&nbsp;&nbsp;{this.state.event.end}</h4>
            
           
            <button className="btn btn-success" onClick={()=>this.apply(this.state.event._id)}>Register</button>
            </div>
            <div className="well">
            <h3>Event Description:</h3>{this.state.event.description}
            <h3>Location:</h3><p>{this.state.event.location}</p>
            <h3>Price for Adult:</h3><p>{this.state.event.adultprice}</p>
            <h3>Price for Child:</h3><p>{this.state.event.childprice}</p>
            <h3>Price for Veg:</h3><p>{this.state.event.vegprice}</p>
            <h3>Price for Non-veg:</h3><p>{this.state.event.nonvegprice}</p>
            <h3>Price for drinks:</h3><p>{this.state.event.drinksprice}</p>
            <h3>Start Booking Time:</h3><p>{this.state.event.startbook}</p>
            <h3>End Booking Time:</h3><p>{this.state.event.endbook}</p>
            </div>
            
         </div>
      );
   }
}
export default EventDetails;