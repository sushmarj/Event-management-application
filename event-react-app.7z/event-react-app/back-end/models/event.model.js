const mongoose =require("mongoose");

const eventSchema =mongoose.Schema({
    eventname:{
        type:String,
        required:true
    },
    start:{
        type:Date,
        required:true
    },
    end:{
        type:Date,
        required:true
    },
    location:{
        type:String,
        required:true
    },
    adultprice:{
        type:Number,
        required:true
    },
    childprice:{
        type:Number,
        required:true
    },
    food:{
        type:String,
        required:true
    },
    drinks:{
        type:String,
        required:true
    },
    Description:{
        type:String,
        required:true
    }
})
const Event= module.exports= mongoose.model('Events', eventSchema);