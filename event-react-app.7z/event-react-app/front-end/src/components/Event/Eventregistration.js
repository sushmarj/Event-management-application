import React, { Component } from 'react';

import  createHistory from 'history/createBrowserHistory';
const history= createHistory();


class EventRegistration extends Component {

    constructor() {
        super();
        this.state = {
            fullname: '',
            email: '',
            mobileno: '',
            headcountadult: '',
            headcountchild:'',
            headcountteen:'',
            eventtype:'',
            food:'',
            drinks:'',

            fullnameError: '',
            emailError: '',
            mobilenoError: '',
            headcountadultError: '',
            
            eventtypeError:'',
            foodError: '',
            drinksError:''
        }
    }

    onChanged = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    validate = () => {
        let isError = false;
        const errors = {
            fullnameError: '',
            emailError: '',
            mobilenoError: '',
            headcountadultError: '',
            eventtypeError:'',
            foodError: '',
            drinksError:''
        };
        if (this.state.fullname.length < 5) {
            isError = true;
            errors.fullnameError = "Full name needs to be atleast 5 characters long";
        }
        if (this.state.fullname === '') {
            isError = true;
            errors.fullnameError = "Full name Required ";
        }

        if (this.state.email.indexOf("@") === -1) {
            isError = true;
            errors.emailError = "Requires valid email";
        }
        if (this.state.mobileno === '') {
            isError = true;
            errors.mobilenoError = "Mobile Number Required ";
        }
        if (this.state.headcountadult === '') {
            isError = true;
            errors.headcountadultError = "Adult headcount Required ";
        }
       
        if (this.state.eventtype === '') {
            isError = true;
            errors.eventtypeError = "Event type Required ";
        }
       
        this.setState({
            ...this.state,
            ...errors
        });

        return isError;
    };



    onSubmit = (event) => {
        event.preventDefault();
        console.log(this.state);
        const err = this.validate();
        if (!err) {
            // clear form
            this.setState({
                fullname: '',
                fullnameError:'',
                email: '',
                emailError:'',
                mobileno: '',
                mobilenoError:'',
                headcountadult: '',
                headcountadultError:'',
                headcountchild:'',
                headcountadultError:'',
                headcountteen:'',
                headcountteenError:'',
                eventtype:'',
                eventtype:'',
                food:'',
                foodError:'',
                drinks:'',
                drinksError:''
            });
            alert("Registered successfully")

            this.props.history.push('/home');
        }


    }

    render() {

        const {  fullname, email, mobileno, headcountadult, headcountchild, headcountteen, eventtype, food, drinks} = this.state;

        return (

            <div className="well">
                <h2>Event Registration</h2>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label> Full Name :</label>
                        <input name="fullname"onChange={this.onChanged}
                            value={fullname} type="text" className="form-control" />
                   <span style={{color: "red"}}>{this.state.fullnameError}</span>
                    </div>

                    <div className="form-group">
                        <label> Email Id :</label>
                        <input name="email" onChange={this.onChanged}
                            value={email} type="email" className="form-control" />
                    <span style={{color: "red"}}>{this.state.emailError}</span>
                    </div>
                    <div className="form-group">
                        <label> Mobile Number :</label>
                        <input name="mobileno" onChange={this.onChanged}
                            value={mobileno} type="number" className="form-control" />
                    <span style={{color: "red"}}>{this.state.mobilenoError}</span>
                    </div>
                    <div className="form-group">
                        <label> Headcount Adult:</label>
                        <input name="headcountadult" placeholder="15-80 years" onChange={this.onChanged}
                            value={headcountadult} type="text" className="form-control" />
                    <span style={{color: "red"}}>{this.state.headcountadultError}</span>
                    </div>
                    <div className="form-group">
                        <label> Headcount child:</label>
                        <input name="headcountchild" placeholder="0-6 years" onChange={this.onChanged}
                            value={headcounchild} type="headcountchild" className="form-control" />
                    
                    </div>
                    <div className="form-group">
                        <label> Headcount teenage:</label>
                        <input name="headcountteen" placeholder="6-15 years" onChange={this.onChanged}
                            value={headcounteen} type="headcountteen" className="form-control" />
                    
                    </div>
                    <div className="form-group">
                        <label> Event type:</label>
                        <input name="eventtype" onChange={this.onChanged}
                            value={eventtype} type="eventtype" className="form-control" />
                    <span style={{color: "red"}}>{this.state.eventtypeError}</span>
                    </div>

                    <div className="form-group">
                        <label> food option :</label>&nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="check"  value="Veg" /> Veg &nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="check"  value="Nonveg" /> Non-veg &nbsp; &nbsp;
                         <input name="food" onChange={this.onChanged}
                            value={food} type="check"  value="notapplicable" /> Not Applicable &nbsp; &nbsp;
                            <span style={{color: "red"}}>{this.state.foodError}</span>
                    </div>
                    <div className="form-group">
                        <label> drinks option :</label>&nbsp; &nbsp;
                        <input name="drinks" onChange={this.onChanged}
                            value={drinks} type="check"  value="applicable" /> Applicable &nbsp; &nbsp;
                        <input name="drinks" onChange={this.onChanged}
                            value={drinks} type="check"  value="notapplicable" /> Not Applicable &nbsp; &nbsp;
                            <span style={{color: "red"}}>{this.state.drinksError}</span>
                    </div>
                    <div className="form-group">
                        <input onChange={this.onChanged} type='check'/>By creating an account, I accept the <a>Terms & Conditions</a>
                    </div>

                    <button className="btn btn-success" type="submit">Sign In</button>

                
                </form>
            </div>

        )
    }
}

export default EventRegistration;


