const express= require('express');
const router =express.Router();
const validate=require('../models/event.model');
const Event= require('../models/event.model.js');

router.get('/', (req, res)=>{
    Event.find((err, result)=>{
        if(err)
        res.status(404).send(err)
        else
        res.status(200).send(result);
    })
})
router.get('/:id', (req, res)=>{
    Event.findById({_id:req.params.id},(err, result)=>{
        if(err)
        res.status(404).send(err)
        else
        res.status(200).send(result);
    })
})
router.delete('/:id',(req,res)=>{
    Event.findByIdAndDelete({_id:req.params.id},(err,result)=>{
    if(err) console.log(err);
    else res.status(200).send(result);
    console.log("Event has been deleted")
   })
})
router.post('/',async(req,res)=>{
    const { error} = validate(req.body)
    if(error) 
       return res.status(400).send(error.details[0].message);
        let newTask=new Event({
        eventname:req.body.eventname,
        start:req.body.start,
        end:req.body.end,
        image:req.body.image,
        location:req.body.location,
        adultprice:req.body.adultprice,
        childprice:req.body.childprice,
        food:req.body.food,
        drinks:req.body.drinks,
        Description:req.body.Description
        });
        newTask.save((err,result)=>{
            if(err) console.log(err);
            else res.status(200).send(result);
        })
  })
router.put('/:id', (req, res)=>{
    Event.findByIdAndUpdate({_id:req.params.id}, {$Set:{
        eventname:req.body.eventname,
        start:req.body.start,
        end:req.body.end,
        image:req.body.image,
        location:req.body.location,
        adultprice:req.body.adultprice,
        childprice:req.body.childprice,
        food:req.body.food,
        drinks:req.body.drinks,
        Description:req.body.Description

    }}, 
    (err, result)=>{
        if(err)
        res.status(404).send(err)
        else
        res.status(200).send(result);
    })
})
module.exports=router
