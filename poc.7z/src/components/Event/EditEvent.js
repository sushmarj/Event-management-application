import React , { Component } from 'react';
import axios from 'axios';

export class EditEvent extends Component {

    constructor(props){
        super(props);
        this.serviceUrl = "http://localhost:5000/api/event/";
        this.state={
            _id:'',
            eventname:"",
            start: "",
            end:"",
            location:"",
            adultprice:"",
            childprice:"",
            vegprice:"",
            nonvegprice:"",
            drinksprice:"", 
            startbook:"",
            endbook:"",
            description: ""
        }
    }

    componentDidMount(){
        let _id=this.props.match.params._id;
        axios.get(this.serviceUrl+_id).then((res)=>{
            this.setState({
                _id:res.data._id,
                eventname:res.data.eventname,
                start:res.data.start,
                end:res.data.end,
                location:res.data.location,
                adultprice:res.data.adultprice,
                childprice:res.data.childprice,
                vegprice:res.data.vegprice,
                nonvegprice:res.data.nonvegprice,
                drinksprice:res.data.drinksprice,
                startbook:res.data.startbook,
                endbook:res.data.endbook,
                description:res.data.description});
        })
    }

    cancelClick=()=>{
        this.props.history.push('/event');
    }

    onChanged=(e)=>{
        this.setState({[e.target.name]:e.target.value})
    }

    onSaveClick=(e)=>{
        e.preventDefault();
        axios.put(this.serviceUrl +this.state._id, this.state).then((res)=>{
            alert('Data Updated');
            this.props.history.push('/event');
        }) 
    }


    render(){
        const {  _id, eventname, start, end, location, adultprice, childprice, vegprice, nonvegprice, drinksprice, startbook, endbook, description} = this.state;
        return(
            <div className="row">
            <div className="col-sm-offset-2 col-sm-8">
            <div className="well">
            <form onSubmit={this.onSaveClick}>
            <div className="form-group">
            <label>Id</label>
            <input name="id" value={_id}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Event Name</label>
            <input name="eventname" value={eventname}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Start</label>
            <input name="start" value={start}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>End</label>
            <input name="end" value={end}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>location</label>
            <input name="location" value={location}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Adult Price</label>
            <input name="adultprice" value={adultprice}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Child Price</label>
            <input name="childprice" value={childprice}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Veg price</label>
            <input name="vegprice" value={vegprice}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Non-Veg price</label>
            <input name="nonvegprice" value={nonvegprice}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Drinks price</label>
            <input name="drinksprice" value={drinksprice}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Start Booking Time</label>
            <input name="startbook" value={startbook}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>End Booking Time</label>
            <input name="endbook" value={endbook}
            onChange={this.onChanged} className="form-control" />
            </div>
            <div className="form-group">
            <label>Description</label>
            <input name="description" value={description}
            onChange={this.onChanged} className="form-control" />
            </div>

            <button type="submit" className="btn btn-success">Save</button>
            <button onClick={this.cancelClick}
            className="btn btn-warning">Cancel</button>
                </form>                
            </div>
            </div></div>
        )
    }
}