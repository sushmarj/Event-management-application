const mongoose =require("mongoose");

const eventregistrationSchema =mongoose.Schema({
    fullname:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    mobileno:{
        type:Number,
        required:true
    },
    headcountadult:{
        type:Number,
        required:true
    },
    headcountchild:{
        type:Number,
        required:true
    },
    headcountteen:{
        type:Number,
        required:true
    },
    eventtype:{
        type:String,
        required:true
    },
    food:{
        type:String,
        required:true
    },
    drinks:{
        type:String,
        required:true
    }
})
const EventReg= module.exports= mongoose.model('EventReg', eventregistrationSchema);